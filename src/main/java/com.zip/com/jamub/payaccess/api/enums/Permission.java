package com.jamub.payaccess.api.enums;

public enum Permission {
    ALL_PERMISSIONS,
    AUTHENTICATE_WITH_OTP
}
