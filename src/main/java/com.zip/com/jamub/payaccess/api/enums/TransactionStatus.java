package com.jamub.payaccess.api.enums;

public enum TransactionStatus {
	PENDING, SUCCESS, FAIL, REVERSED, PAIDOUT, CUSTOMER_CANCELED, REQUEST_ROLLBACK
}
