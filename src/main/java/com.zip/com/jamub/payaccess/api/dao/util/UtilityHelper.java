package com.jamub.payaccess.api.dao.util;

import org.apache.commons.lang3.RandomStringUtils;
import org.mindrot.jbcrypt.BCrypt;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.multipart.MultipartFile;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

public class UtilityHelper {

    private final static Logger logger = LoggerFactory.getLogger(UtilityHelper.class);
    public static String generateBCryptPassword(String password)
    {
        String generatedSecuredPasswordHash = BCrypt.hashpw(password, BCrypt.gensalt(12));
        return generatedSecuredPasswordHash;
    }

    public static String uploadFile(MultipartFile identificationDocumentPath, String fileDestinationPath) throws IOException {
        logger.info("identificationDocumentPath ...{}", identificationDocumentPath.getSize());
        byte[] fileBytes = identificationDocumentPath.getBytes();
        String pathName = identificationDocumentPath.getOriginalFilename();
        String newFileName = RandomStringUtils.randomAlphanumeric(16);
        String newFileNameExt = pathName.substring(pathName.lastIndexOf(".") + 1);
        File destinationFile = new File(fileDestinationPath + File.separator + newFileName + "." + newFileNameExt);
        BufferedOutputStream is = new BufferedOutputStream(new FileOutputStream(destinationFile));
        is.write(fileBytes);
        is.close();

        return newFileName + "." + newFileNameExt;
    }
}
