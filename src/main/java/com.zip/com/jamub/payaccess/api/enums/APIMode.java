package com.jamub.payaccess.api.enums;

public enum APIMode {
	TEST, LIVE
}
