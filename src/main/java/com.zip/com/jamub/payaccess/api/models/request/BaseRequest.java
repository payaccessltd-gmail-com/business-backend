package com.jamub.payaccess.api.models.request;

public class BaseRequest {
}
