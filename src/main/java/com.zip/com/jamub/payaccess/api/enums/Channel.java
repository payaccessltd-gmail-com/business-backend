package com.jamub.payaccess.api.enums;

public enum Channel {
	WEB, POS, ONLINE_BANKING, MOBILE, WALLET, ATM, NOT_SPECIFIED, SYSTEM, USSD
}
