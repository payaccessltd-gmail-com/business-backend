package com.jamub.payaccess.api.enums;

public enum PayAccessCurrency {
	NGN, USD
}
