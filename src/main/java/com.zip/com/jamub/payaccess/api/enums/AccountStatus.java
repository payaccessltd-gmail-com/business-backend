package com.jamub.payaccess.api.enums;

public enum AccountStatus {
	ACTIVE, INACTIVE, DISABLED
}
