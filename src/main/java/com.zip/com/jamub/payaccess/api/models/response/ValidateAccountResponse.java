package com.jamub.payaccess.api.models.response;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ValidateAccountResponse {

    private String accountName;
}
